%%  Add paths to source 

addpath(genpath('architecture'));
addpath(genpath('differential evolution'));
addpath(genpath('generatore segnali sintetici'));
addpath(genpath('utils'));

basePath = 'perceptron';


%%  Generate training for archetypes
syntheticSignals(basePath, 1, 10, 0.1, 10);

%%  Optimize delta
optimizeDeltaBoundaries(basePath, 2, 1);


%%  Normalizes signal and divides it in windows
raw2windows(basePath, 2);

%%  Train and compute the archeypal behavior assessment

firstLevelPerceptronDoubleC(basePath, true, false); %just training

%% First level run
firstLevelPerceptronDoubleC(basePath, false, true); %no training, just compute
